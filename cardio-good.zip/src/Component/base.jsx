import axios from 'axios';
import React, { Component } from 'react';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import Edit from './edit';
import Chart from './chart';
import Data from './data';
import Newuser from './newuser';

export default class Base extends Component {
    constructor(props) {
        super(props);


    }

    render() {
        return (
            <div>

<Router>
        <Switch>
            <Route path="/controller/" exact Component={Chart}></Route>
            <Route path="/controller/addsub/:user" exact Component={Newuser}></Route>
            <Route path="/controller/update/:id" exact component={Edit}></Route>
        </Switch>
        <Data />
        </Router>
            
            </div>

        )
    }


}