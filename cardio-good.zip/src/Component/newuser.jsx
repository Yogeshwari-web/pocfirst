import React, { Component } from 'react';
import { Formik, Form, Field } from 'formik';
import axios from 'axios';
//import ListCapacity from './ListCapacity';
//importLungDataServicefrom'../Service/LungDataService'

export default class Newuser extends Component {
    constructor(props) {
        super(props)
        this.state = {
            //id:this.props.match.params.id
            product: '',
            age: 0,
            education: 0,
            fitness: 0,
            gender: '',
            income: 0,
            martialStatus: '',
            miles: 0,
            usuage: 0
        }
        this.onSubmits = this.onSubmits.bind(this)
    }

    componentDidMount() {

        console.log(this.state.id)

    }
    onSubmits(values) {
        console.log(this.state.age);
        const user = {
            product: values.product,
            age: values.age,
            education: values.education,
            fitness: values.fitness,
            gender: values.gender,
            income: values.income,
            martialStatus: values.martialStatus,
            miles: values.miles,
            usuage: values.usuage

        }
        console.log(values.age);
        axios.post(`http://localhost:7072/controller/addsub`, user)
    }
    render() {

        // let description = this.state.description
        //let id = this.state.id
        return (
            <div>
               <center><h3>PURCHASING TREADMILL </h3></center>
                <div className="container">
                    <Formik
                        initialValues={this.state}
                        onSubmit={this.onSubmits}
                    >
                        {
                            (props) => (
                                <Form>
                                    <fieldset className="form-group">
                                        <label>product</label>
                                        <Field className="form-control" type="text" name="product" />
                                    </fieldset>
                                    <fieldset className="form-group1">
                                        <label>Age</label>
                                        <Field className="form-control" type="number" name="age" />
                                    </fieldset>
                                    <fieldset className="form-group2">
                                        <label>Education</label>
                                        <Field className="form-control" type="number" name="education" />
                                    </fieldset>
                                    <fieldset className="form-group3">
                                        <label>Fitness</label>
                                        <Field className="form-control" type="number" name="fitness" />
                                    </fieldset>
                                    <fieldset className="form-group4">
                                        <label>Gender</label>
                                        <Field className="form-control" type="text" name="gender" />
                                    </fieldset>
                                    <fieldset className="form-group5">
                                        <label>Income</label>
                                        <Field className="form-control" type="number" name="income" />
                                    </fieldset>
                                    <fieldset className="form-group6">
                                        <label>Marital status</label>
                                        <Field className="form-control" type="text" name="martialStatus" />
                                    </fieldset>
                                    <fieldset className="form-group7">
                                        <label>Miles</label>
                                        <Field className="form-control" type="number" name="miles" />
                                    </fieldset>
                                    <fieldset className="form-group8">
                                        <label>Usuage</label>
                                        <Field className="form-control" type="number" name="usuage" />
                                    </fieldset>
                                    <button className="btn btn-success" type="submit">submit</button>
                                </Form>
                            )
                        }

                    </Formik>
                </div>
            </div>
        )
    }
}
