import React,{Component} from  'react';
import {Bar, Line, Pie} from 'react-chartjs-2';
import axios from 'axios';


class Chart extends Component{
        constructor(props){
            super(props);
            this.state = {
                chartData :{

                    labels: ['TM195', 'TM498', 'TM798'],
                    datasets: [{
                        label: 'My First dataset',
                        backgroundColor: ['rgb(255, 99, 132)','rgb(78,108,192)','rgb(247,62,5)'],
                        borderColor: 'rgb(255, 99, 132),',
                        data: [81,60,39]
                    }]
            

                }                
            
            }
            this.getValue = this.getValue.bind(this);
        }
        async componentDidMount(){
            let thisVal=await this.getValue();
            let count = thisVal.data.length;
            console.log(count);
            var arr=[],c1=0,c2=0,c3=0;
      
            thisVal.data.map((value, index)=>{
                    let sample = value
                    //var count = sample.length
                    //console.log(count)
                    
                    
                        if(sample.product==="TM195")
                        c1=c1+1
                    else if(sample.product === "TM498")
                        c2=c2+1
                    else if(sample.product === "TM798")
                        c3=c3+1
                        arr[0]=c1;
                        arr[1]=c2;
                        arr[2]=c3;
                         
                    
                    return arr 
            });
            console.log(arr)
            console.log("Before"+this.state.data)
            this.setState({data:arr})        
            
            console.log("After"+this.state.data)
            
        }

        getValue = async() =>{
            let request =await axios.get('http://localhost:7072/controller/users');
                console.log(request)
                             
                return request;
            
        }
    

    render(){
        return(
            <div className="chart">
                <center><b>CHART COMPONENT <br></br>
                    PURCHASED DETAILS OF THE THREADMILLS</b></center>
                <Bar
                    data={this.state.chartData}
                    options={{ maintainAspectRatio: false }}
                />
                       
            </div>
        )
    }
}

export default Chart;