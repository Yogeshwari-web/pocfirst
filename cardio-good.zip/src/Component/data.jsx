import ReactDOM from 'react-dom';
import axios from 'axios';
import { Table, Button } from 'reactstrap';
import React, { Component } from 'react';
import { withRouter } from 'react-router';


class Data extends Component {
    constructor(props) {
        super(props);
        this.delete = this.delete.bind(this);
        this.edit = this.edit.bind(this);
        this.state = {
            value: []
        }
    }

    async componentDidMount() {
        let thisVal = await this.getValue();
        this.setState({ value: thisVal })
        //await this.getValue();
    }
    async delete(id) {
        await axios.delete(`http://localhost:7072/controller/delete/${id}`);
        let thisVal = await this.getValue();
        this.setState({ value: thisVal })
    }
    async edit(value) {
        this.props.history.push(`/controller/update/${value.id}`)
    }
    async newUser() {
        console.log("hew user");
        this.props.history.push(`/controller/addsub`)
    }

    getValue = async () => {
        let request = await axios.get('http://localhost:7072/controller/users');

        //<h1>Hello World</h1>
        let array = request.data.map((value, index) => {
            return (
                <tr key={value.id}>
                    <td>{value.id}</td>
                    <td>{value.age}</td>
                    <td>{value.education}</td>
                    <td>{value.fitness}</td>
                    <td>{value.gender}</td>
                    <td>{value.income}</td>
                    <td>{value.martialStatus}</td>
                    <td>{value.miles}</td>
                    <td>{value.product}</td>
                    <td>{value.usage}</td>
                    <td><Button color="success" size="sm" onClick={() => this.edit(value)}>Edit</Button></td>
                    <td><Button color="danger" size="sm" onClick={() => this.delete(value.id)}>Delete</Button></td>

                </tr>
            )
        })
        return array;

    }
    render() {
        return (
            <div>
                <h3>ADDING A NEW USER</h3>
                <Button color="success" size="sm" onClick={() => this.newUser}>Edit</Button>

                <Table >
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>AGE</th>
                            <th>EDUCATION</th>
                            <th>FITNESS</th>
                            <th>GENDER</th>
                            <th>INCOME</th>
                            <th>MARITAL STATUS</th>
                            <th>MILES</th>
                            <th>PRODUCT</th>
                            <th>USUAGE</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.value}
                    </tbody>
                </Table>
            </div>
        )
    }


}
export default withRouter(Data)