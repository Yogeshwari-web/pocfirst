import React, { Component } from 'react'
import { Formik, Form, Field } from 'formik';
import axios from 'axios';
//import ListCapacity from './ListCapacity';
//importLungDataServicefrom'../Service/LungDataService'
import Data from './data';
class Edit extends Component {
    constructor(props) {
        super(props)
        this.state = {
           //id: this.props.match.params.id
        }
        this.onSubmits = this.onSubmits.bind(this)
    }
    // componentDidMount() {
    //     console.log(this.state.id)
    //     if (this.state.id == -1) {
    //         return
    //     }

    //         .then(response => this.setState({
    //             product: response.data.product,
    //             age:response.data.age,
    //             education: response.data.education,
    //             fitness: response.data.fitness,
    //             gender:response.data.gender,
    //             income:response.data.income,
    //             martialStatus:response.data.martialStatus,
    //             miles : response.data.miles,
    //             usuage: response.data.usuage
    //         }))
    // }
    onSubmits(values) {
        console.log(this.state.age);
        let edited = {
            id: values.id,
            age: values.age,
            caesarean: values.caesarean,
            capacity: values.capacity,
            gender: values.gender,
            height: values.height,
            smoke: values.smoke

        }
        console.log(values.age);
        axios.post(`http://localhost:7072/controller/update/${this.id}`)
    }

    render() {

        //let description=this.state.description
        
        //console.log(details)
        let id = this.state.id
        return (
            <div>
                <h3>Edit User Details</h3>
                <div className="container">
                    <Formik
                        initialValues={this.state}
                        onSubmit={this.onSubmits}
                    >
                        {
                            (props) => (
                                <Form>
                                    <fieldset className="form-group9">
                                        <label>Id</label>
                                        <Field className="form-control" type="text" name="id" value={id} disabled />
                                    </fieldset>

                                    <fieldset className="form-group">
                                        <label>product</label>
                                        <Field className="form-control" type="text" name="product" />
                                    </fieldset>
                                    <fieldset className="form-group1">
                                        <label>Age</label>
                                        <Field className="form-control" type="number" name="age" />
                                    </fieldset>
                                    <fieldset className="form-group2">
                                        <label>Education</label>
                                        <Field className="form-control" type="number" name="education" />
                                    </fieldset>
                                    <fieldset className="form-group3">
                                        <label>Fitness</label>
                                        <Field className="form-control" type="number" name="fitness" />
                                    </fieldset>
                                    <fieldset className="form-group4">
                                        <label>Gender</label>
                                        <Field className="form-control" type="text" name="gender" />
                                    </fieldset>
                                    <fieldset className="form-group5">
                                        <label>Income</label>
                                        <Field className="form-control" type="number" name="income" />
                                    </fieldset>
                                    <fieldset className="form-group6">
                                        <label>Marital status</label>
                                        <Field className="form-control" type="text" name="martialStatus" />
                                    </fieldset>
                                    <fieldset className="form-group7">
                                        <label>Miles</label>
                                        <Field className="form-control" type="number" name="miles" />
                                    </fieldset>
                                    <fieldset className="form-group8">
                                        <label>Usuage</label>
                                        <Field className="form-control" type="number" name="usuage" />
                                    </fieldset>
                                    <button className="btn btn-success" type="submit">submit</button>
                                </Form>
                            )
                        }

                    </Formik>
                </div>
            </div>
        )
    }
}

export default Edit
