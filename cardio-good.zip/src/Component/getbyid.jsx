import axios from 'axios';
import { Formik, Form, Field } from 'formik';
//import { Button } from 'reactstrap';
import React, { Component } from 'react';

export default class Getbyid extends Component {
    constructor(props) {
        super(props);
        this.state = {
        //id : this.props.match.params.id
        }
        this.search = this.search.bind(this);
    }
    componentDidMount() {

        console.log(this.state.id)

    }

    async search(id) {

        await axios.get(`http://localhost:7072/controller/users/${id}`);
        console.log("list the user details");

    }

    render() {
        let id=this.state.id

        return (
            <div>
               <div className="container">
                    <Formik
                        initialValues={this.state}
                        onSubmit={this.onSubmits}
                    >
                        {
                            (props) => (
                                <Form>
                                    <fieldset className="form-group">
                                        <label>Enter Id</label>
                                        <Field className="form-control" type="number" name="id"value={id} />
                                    </fieldset>
                                    <button className="btn btn-success" type="submit">submit</button>
                                </Form>
                            )
                        }

                    </Formik>
                </div>
                          
            </div>

        )
    }
}