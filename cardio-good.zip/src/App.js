import React from 'react';
import './App.css';
import Chart from './Component/chart';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import Base from './Component/base';
function App() {
  return (
    <div>
      
      <center><h1>CARDIO GOOD FITNESS</h1></center>

      <Chart />  
      
      <Base />
      
      {/* <Chart></Chart>
      
      <Newuser></Newuser>

      <Chart></Chart> */}
      </div>
  )
}

export default App;
